<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cobratario extends Model
{
    use HasFactory;
    protected $table = 'cobratarios';
    protected $fillable = ['nombre'];

}
