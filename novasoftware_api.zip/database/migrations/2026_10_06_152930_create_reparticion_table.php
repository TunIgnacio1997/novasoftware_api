<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reparticion', function (Blueprint $table) {
            $table->increments('id');
            $table->string('descripcion', 50)->nullable();
            $table->dateTime('id_fecha');
            $table->integer('id_usuario');
            $table->integer('id_sucursal');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reparticion');
    }
};
